function toast (x ,y, width, length, fontSize, message, bg) {

    

    if (count>= 300) {
        bg()
    }

    

}