
function gameInProgress() {
    background(255)
    textSize(20)
    textAlign(CENTER)
    text("Game already in progress. Please wait.", w/2, l*0.2);

}